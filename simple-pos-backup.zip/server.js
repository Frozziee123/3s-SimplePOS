const express = require("express");
const path = require("path");
const crypto = require("crypto");
const db = require("./db");

const app = express();
const PORT = 3000;
const LOW_STOCK_THRESHOLD = 5;
const sessions = new Map();

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function getUserFromToken(req) {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;
  return token ? sessions.get(token) : null;
}

function requireAuth(req, res, next) {
  const user = getUserFromToken(req);
  if (!user) return res.status(401).json({ error: "Unauthorized" });
  req.user = user;
  next();
}

function requireAdmin(req, res, next) {
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Admin only" });
  }
  next();
}

app.post("/api/login", (req, res) => {
  const { username, password } = req.body;
  const user = db
    .prepare("SELECT id, username, role FROM users WHERE username = ? AND password = ?")
    .get(username, password);
  if (!user) return res.status(401).json({ error: "Invalid credentials" });

  const token = crypto.randomUUID();
  sessions.set(token, user);
  res.json({ token, user });
});

app.post("/api/logout", requireAuth, (req, res) => {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;
  if (token) sessions.delete(token);
  res.json({ ok: true });
});

app.get("/api/products", requireAuth, (req, res) => {
  const rows = db.prepare("SELECT * FROM products ORDER BY id DESC").all();
  res.json(rows);
});

app.post("/api/products", requireAuth, requireAdmin, (req, res) => {
  const { name, price, stock } = req.body;
  const info = db
    .prepare("INSERT INTO products (name, price, stock) VALUES (?, ?, ?)")
    .run(name, Number(price || 0), Number(stock || 0));
  res.json({ id: info.lastInsertRowid });
});

app.put("/api/products/:id", requireAuth, requireAdmin, (req, res) => {
  const { name, price, stock } = req.body;
  db.prepare("UPDATE products SET name = ?, price = ?, stock = ? WHERE id = ?").run(
    name,
    Number(price || 0),
    Number(stock || 0),
    req.params.id
  );
  res.json({ ok: true });
});

app.delete("/api/products/:id", requireAuth, requireAdmin, (req, res) => {
  db.prepare("DELETE FROM products WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

app.post("/api/transactions", requireAuth, (req, res) => {
  const { items = [], discount = 0, cash = 0 } = req.body;
  if (!items.length) return res.status(400).json({ error: "Empty cart" });

  const run = db.transaction(() => {
    let gross = 0;
    const preparedItems = [];
    for (const item of items) {
      const product = db.prepare("SELECT * FROM products WHERE id = ?").get(item.product_id);
      if (!product) throw new Error(`Product ${item.product_id} not found`);
      const qty = Number(item.qty || 0);
      if (qty <= 0) throw new Error("Quantity must be > 0");
      if (product.stock < qty) throw new Error(`Insufficient stock for ${product.name}`);
      const subtotal = Number(product.price) * qty;
      gross += subtotal;
      preparedItems.push({ product, qty, subtotal });
    }

    const total = Math.max(0, gross - Number(discount || 0));
    const cashNum = Number(cash || 0);
    if (cashNum < total) throw new Error("Cash is less than total");
    const change = cashNum - total;

    const txInfo = db
      .prepare(
        "INSERT INTO transactions (total, discount, cash, change, cashier_id) VALUES (?, ?, ?, ?, ?)"
      )
      .run(total, Number(discount || 0), cashNum, change, req.user.id);
    const txId = txInfo.lastInsertRowid;

    const insertItem = db.prepare(
      "INSERT INTO transaction_items (transaction_id, product_id, name_snapshot, price_snapshot, qty, subtotal) VALUES (?, ?, ?, ?, ?, ?)"
    );
    const updateStock = db.prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
    for (const p of preparedItems) {
      insertItem.run(
        txId,
        p.product.id,
        p.product.name,
        p.product.price,
        p.qty,
        p.subtotal
      );
      updateStock.run(p.qty, p.product.id);
    }
    return { txId, total, change };
  });

  try {
    res.json(run());
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.get("/api/transactions", requireAuth, (req, res) => {
  const { from, to } = req.query;
  let rows;
  if (from && to) {
    rows = db
      .prepare(
        "SELECT t.*, u.username AS cashier_name FROM transactions t LEFT JOIN users u ON u.id = t.cashier_id WHERE date(t.created_at) BETWEEN date(?) AND date(?) ORDER BY t.id DESC"
      )
      .all(from, to);
  } else {
    rows = db
      .prepare(
        "SELECT t.*, u.username AS cashier_name FROM transactions t LEFT JOIN users u ON u.id = t.cashier_id ORDER BY t.id DESC"
      )
      .all();
  }
  res.json(rows);
});

app.get("/api/transactions/:id/receipt", requireAuth, (req, res) => {
  const tx = db.prepare("SELECT * FROM transactions WHERE id = ?").get(req.params.id);
  if (!tx) return res.status(404).json({ error: "Transaction not found" });
  const items = db
    .prepare("SELECT * FROM transaction_items WHERE transaction_id = ?")
    .all(req.params.id);
  res.json({ tx, items });
});

app.get("/api/dashboard", requireAuth, (req, res) => {
  const todaySales =
    db
      .prepare(
        "SELECT IFNULL(SUM(total), 0) AS total FROM transactions WHERE date(created_at) = date('now', 'localtime')"
      )
      .get().total || 0;
  const todayTx =
    db
      .prepare(
        "SELECT COUNT(*) AS count FROM transactions WHERE date(created_at) = date('now', 'localtime')"
      )
      .get().count || 0;
  const todayExpenses =
    db
      .prepare(
        "SELECT IFNULL(SUM(amount), 0) AS total FROM expenses WHERE date(created_at) = date('now', 'localtime')"
      )
      .get().total || 0;
  const lowStock = db
    .prepare("SELECT * FROM products WHERE stock <= ? ORDER BY stock ASC")
    .all(LOW_STOCK_THRESHOLD);
  res.json({
    todaySales,
    todayTx,
    todayExpenses,
    quickSummary: todaySales - todayExpenses,
    lowStock,
  });
});

app.get("/api/sales-summary/daily", requireAuth, (req, res) => {
  const rows = db
    .prepare(
      "SELECT date(created_at) AS day, COUNT(*) AS tx_count, IFNULL(SUM(total), 0) AS total_sales FROM transactions GROUP BY date(created_at) ORDER BY day DESC"
    )
    .all();
  res.json(rows);
});

app.get("/api/borrowers", requireAuth, (req, res) => {
  const rows = db
    .prepare(
      `SELECT b.id, b.name,
      IFNULL((SELECT SUM(amount) FROM utang_entries ue WHERE ue.borrower_id = b.id), 0) AS total_utang,
      IFNULL((SELECT SUM(amount) FROM utang_payments up WHERE up.borrower_id = b.id), 0) AS total_paid
      FROM borrowers b ORDER BY b.id DESC`
    )
    .all()
    .map((r) => ({ ...r, balance: r.total_utang - r.total_paid }));
  res.json(rows);
});

app.post("/api/borrowers", requireAuth, (req, res) => {
  const info = db.prepare("INSERT INTO borrowers (name) VALUES (?)").run(req.body.name);
  res.json({ id: info.lastInsertRowid });
});

app.post("/api/borrowers/:id/utang", requireAuth, (req, res) => {
  const { description, amount } = req.body;
  db.prepare("INSERT INTO utang_entries (borrower_id, description, amount) VALUES (?, ?, ?)").run(
    req.params.id,
    description || "Utang entry",
    Number(amount || 0)
  );
  res.json({ ok: true });
});

app.post("/api/borrowers/:id/payments", requireAuth, (req, res) => {
  db.prepare("INSERT INTO utang_payments (borrower_id, amount) VALUES (?, ?)").run(
    req.params.id,
    Number(req.body.amount || 0)
  );
  res.json({ ok: true });
});

app.get("/api/employees", requireAuth, requireAdmin, (req, res) => {
  const rows = db.prepare("SELECT * FROM employees ORDER BY id DESC").all();
  res.json(rows);
});

app.post("/api/employees", requireAuth, requireAdmin, (req, res) => {
  const info = db.prepare("INSERT INTO employees (name) VALUES (?)").run(req.body.name);
  res.json({ id: info.lastInsertRowid });
});

app.post("/api/employees/:id/time-in", requireAuth, (req, res) => {
  db.prepare("INSERT INTO employee_shifts (employee_id) VALUES (?)").run(req.params.id);
  res.json({ ok: true });
});

app.post("/api/employees/:id/time-out", requireAuth, (req, res) => {
  db.prepare(
    "UPDATE employee_shifts SET time_out = CURRENT_TIMESTAMP WHERE employee_id = ? AND time_out IS NULL"
  ).run(req.params.id);
  res.json({ ok: true });
});

app.get("/api/shifts", requireAuth, (req, res) => {
  const rows = db
    .prepare(
      "SELECT s.*, e.name AS employee_name FROM employee_shifts s JOIN employees e ON e.id = s.employee_id ORDER BY s.id DESC LIMIT 100"
    )
    .all();
  res.json(rows);
});

app.get("/api/expenses", requireAuth, (req, res) => {
  const rows = db.prepare("SELECT * FROM expenses ORDER BY id DESC").all();
  const total = db.prepare("SELECT IFNULL(SUM(amount), 0) AS total FROM expenses").get().total;
  res.json({ rows, total });
});

app.post("/api/expenses", requireAuth, (req, res) => {
  db.prepare("INSERT INTO expenses (description, amount) VALUES (?, ?)").run(
    req.body.description,
    Number(req.body.amount || 0)
  );
  res.json({ ok: true });
});

app.delete("/api/expenses/:id", requireAuth, (req, res) => {
  db.prepare("DELETE FROM expenses WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`Simple POS running at http://localhost:${PORT}`);
});
