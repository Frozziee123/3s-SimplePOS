# Simple POS System

Web-based POS system with SQLite database.

## Features Included

- Admin and Cashier login
- POS cashier flow: cart, quantity change, discount, cash payment, change, receipt view, void item
- Inventory management: add/edit/delete products, stock tracking, low stock indicator
- Sales and reports: daily summary, transaction list, receipt history, date filtering
- Utang (credit): borrower list, utang entries, partial/full payment tracking, remaining balance
- Employee management: add employee, time in/out, shift history
- Expenses: add/delete expense, total expenses
- Dashboard: today's sales, transaction count, low stock alerts, quick summary

## Tech Stack

- Node.js + Express
- SQLite (`better-sqlite3`)
- Vanilla HTML/CSS/JS frontend

## Setup

1. Install Node.js (LTS): [https://nodejs.org](https://nodejs.org)
2. In project folder:
   - `npm install`
   - `npm start`
3. Open [http://localhost:3000](http://localhost:3000)

## Default Accounts

- Admin: `admin` / `admin123`
- Cashier: `cashier` / `cashier123`

## Notes

- Database file is `pos.db` and is auto-created on first run.
- This is a practical starter version. Passwords are stored in plain text for simplicity and should be hashed in production.
